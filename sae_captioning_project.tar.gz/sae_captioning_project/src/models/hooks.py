"""
Activation Hooks for Vision-Language Models
============================================

Utilities for extracting and caching intermediate activations
from transformer models during inference.
"""

import torch
import torch.nn as nn
from typing import Dict, List, Optional, Callable, Any, Tuple
from collections import defaultdict
from dataclasses import dataclass, field
import gc


@dataclass
class HookConfig:
    """Configuration for activation hooks."""
    layers: List[int]
    component: str = "residual"  # residual, mlp, attention
    position: str = "post"  # pre, mid, post
    detach: bool = True
    to_cpu: bool = True
    dtype: Optional[torch.dtype] = None


class ActivationCache:
    """
    Cache for storing intermediate activations during forward passes.
    
    Supports:
    - Selective layer caching
    - Multiple component types (residual stream, MLP, attention)
    - Memory-efficient storage with CPU offloading
    - Batch accumulation
    """
    
    def __init__(
        self,
        model: nn.Module,
        config: HookConfig,
        model_type: str = "gemma"
    ):
        """
        Initialize activation cache.
        
        Args:
            model: The transformer model
            config: Hook configuration
            model_type: Model architecture type ("gemma", "llama", "mistral")
        """
        self.model = model
        self.config = config
        self.model_type = model_type
        
        self.activations: Dict[str, List[torch.Tensor]] = defaultdict(list)
        self.hooks: List[torch.utils.hooks.RemovableHandle] = []
        self.metadata: Dict[str, Any] = {}
        
        self._setup_hooks()
    
    def _get_layer_module(self, layer_idx: int) -> nn.Module:
        """Get the transformer layer module by index."""
        if self.model_type in ["gemma", "llama", "mistral"]:
            return self.model.model.layers[layer_idx]
        elif self.model_type == "gpt2":
            return self.model.transformer.h[layer_idx]
        else:
            raise ValueError(f"Unknown model type: {self.model_type}")
    
    def _get_component_module(self, layer: nn.Module) -> nn.Module:
        """Get the specific component to hook within a layer."""
        component = self.config.component
        
        if component == "residual":
            return layer  # Hook the entire layer for residual stream
        elif component == "mlp":
            return layer.mlp if hasattr(layer, 'mlp') else layer.feed_forward
        elif component == "attention":
            return layer.self_attn if hasattr(layer, 'self_attn') else layer.attention
        else:
            raise ValueError(f"Unknown component: {component}")
    
    def _make_hook(self, name: str) -> Callable:
        """Create a forward hook function."""
        def hook(module: nn.Module, input: Tuple, output: Any) -> None:
            # Handle different output types
            if isinstance(output, tuple):
                activation = output[0]
            else:
                activation = output
            
            # Detach from computation graph
            if self.config.detach:
                activation = activation.detach()
            
            # Convert dtype if specified
            if self.config.dtype is not None:
                activation = activation.to(self.config.dtype)
            
            # Move to CPU if configured
            if self.config.to_cpu:
                activation = activation.cpu()
            
            # Store activation
            self.activations[name].append(activation)
        
        return hook
    
    def _setup_hooks(self) -> None:
        """Register hooks on specified layers."""
        for layer_idx in self.config.layers:
            layer = self._get_layer_module(layer_idx)
            
            if self.config.component == "residual":
                # For residual stream, hook the layer output
                hook = layer.register_forward_hook(
                    self._make_hook(f"layer_{layer_idx}")
                )
            else:
                # For specific components
                component = self._get_component_module(layer)
                hook = component.register_forward_hook(
                    self._make_hook(f"layer_{layer_idx}_{self.config.component}")
                )
            
            self.hooks.append(hook)
    
    def clear(self) -> None:
        """Clear cached activations."""
        self.activations = defaultdict(list)
        gc.collect()
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
    
    def remove_hooks(self) -> None:
        """Remove all registered hooks."""
        for hook in self.hooks:
            hook.remove()
        self.hooks = []
    
    def get_activations(self, layer_idx: int) -> List[torch.Tensor]:
        """Get cached activations for a specific layer."""
        key = f"layer_{layer_idx}"
        if self.config.component != "residual":
            key = f"{key}_{self.config.component}"
        return self.activations.get(key, [])
    
    def get_stacked_activations(self, layer_idx: int) -> torch.Tensor:
        """Get stacked activations for a layer (batch dim first)."""
        acts = self.get_activations(layer_idx)
        if not acts:
            raise ValueError(f"No activations found for layer {layer_idx}")
        return torch.cat(acts, dim=0)
    
    def get_all_layers(self) -> Dict[int, torch.Tensor]:
        """Get stacked activations for all cached layers."""
        result = {}
        for layer_idx in self.config.layers:
            try:
                result[layer_idx] = self.get_stacked_activations(layer_idx)
            except ValueError:
                continue
        return result
    
    def __enter__(self):
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.remove_hooks()
        self.clear()


class VisionLanguageActivationExtractor:
    """
    Specialized activation extractor for vision-language models.
    
    Handles the complexity of multimodal inputs and tracks both
    image and text token positions.
    """
    
    def __init__(
        self,
        model: nn.Module,
        processor: Any,
        layers: List[int],
        device: str = "cuda",
        model_type: str = "gemma"
    ):
        """
        Initialize the extractor.
        
        Args:
            model: Vision-language model
            processor: Model processor/tokenizer
            layers: Layers to extract from
            device: Device to use
            model_type: Model architecture type
        """
        self.model = model
        self.processor = processor
        self.layers = layers
        self.device = device
        self.model_type = model_type
    
    @torch.no_grad()
    def extract(
        self,
        images: List[Any],
        prompts: List[str],
        batch_size: int = 4,
        return_token_positions: bool = True
    ) -> Dict[str, Any]:
        """
        Extract activations for image-prompt pairs.
        
        Args:
            images: List of PIL images or image paths
            prompts: List of text prompts
            batch_size: Batch size for processing
            return_token_positions: Whether to return token position info
            
        Returns:
            Dictionary containing:
                - activations: Dict[layer_idx, Tensor]
                - token_info: Optional position information
        """
        self.model.eval()
        
        config = HookConfig(
            layers=self.layers,
            component="residual",
            detach=True,
            to_cpu=True,
            dtype=torch.float32
        )
        
        all_activations = {layer: [] for layer in self.layers}
        all_token_info = []
        
        # Process in batches
        for i in range(0, len(images), batch_size):
            batch_images = images[i:i + batch_size]
            batch_prompts = prompts[i:i + batch_size]
            
            # Prepare inputs
            inputs = self.processor(
                images=batch_images,
                text=batch_prompts,
                return_tensors="pt",
                padding=True
            )
            inputs = {k: v.to(self.device) for k, v in inputs.items()}
            
            # Extract with hooks
            with ActivationCache(self.model, config, self.model_type) as cache:
                outputs = self.model(**inputs, output_hidden_states=False)
                
                # Collect activations
                for layer in self.layers:
                    acts = cache.get_stacked_activations(layer)
                    all_activations[layer].append(acts)
            
            # Track token positions if requested
            if return_token_positions:
                token_info = self._get_token_positions(inputs, batch_prompts)
                all_token_info.extend(token_info)
        
        # Stack all batches
        result = {
            "activations": {
                layer: torch.cat(acts, dim=0)
                for layer, acts in all_activations.items()
            }
        }
        
        if return_token_positions:
            result["token_info"] = all_token_info
        
        return result
    
    def _get_token_positions(
        self,
        inputs: Dict[str, torch.Tensor],
        prompts: List[str]
    ) -> List[Dict[str, Any]]:
        """Extract token position information from inputs."""
        token_info = []
        
        # This is model-specific - adjust based on your model
        input_ids = inputs.get("input_ids")
        attention_mask = inputs.get("attention_mask")
        
        if input_ids is None:
            return token_info
        
        for b in range(input_ids.shape[0]):
            # Find image vs text token positions
            # This varies by model - adjust accordingly
            info = {
                "total_tokens": attention_mask[b].sum().item() if attention_mask is not None else input_ids.shape[1],
                "prompt": prompts[b] if b < len(prompts) else None,
            }
            token_info.append(info)
        
        return token_info
    
    @torch.no_grad()
    def extract_with_generation(
        self,
        images: List[Any],
        prompts: List[str],
        max_new_tokens: int = 50,
        batch_size: int = 4
    ) -> Dict[str, Any]:
        """
        Extract activations during generation.
        
        Returns activations from the generation process, including
        the generated output text.
        """
        self.model.eval()
        
        config = HookConfig(
            layers=self.layers,
            component="residual",
            detach=True,
            to_cpu=True
        )
        
        results = {
            "activations": {layer: [] for layer in self.layers},
            "generated_texts": [],
            "input_prompts": []
        }
        
        for i in range(0, len(images), batch_size):
            batch_images = images[i:i + batch_size]
            batch_prompts = prompts[i:i + batch_size]
            
            inputs = self.processor(
                images=batch_images,
                text=batch_prompts,
                return_tensors="pt",
                padding=True
            )
            inputs = {k: v.to(self.device) for k, v in inputs.items()}
            
            with ActivationCache(self.model, config, self.model_type) as cache:
                outputs = self.model.generate(
                    **inputs,
                    max_new_tokens=max_new_tokens,
                    do_sample=False,
                    output_hidden_states=False
                )
                
                for layer in self.layers:
                    acts = cache.get_stacked_activations(layer)
                    results["activations"][layer].append(acts)
            
            # Decode outputs
            generated = self.processor.batch_decode(
                outputs,
                skip_special_tokens=True
            )
            results["generated_texts"].extend(generated)
            results["input_prompts"].extend(batch_prompts)
        
        # Stack activations
        results["activations"] = {
            layer: torch.cat(acts, dim=0)
            for layer, acts in results["activations"].items()
        }
        
        return results


def create_activation_extractor(
    model: nn.Module,
    processor: Any,
    layers: List[int],
    device: str = "cuda"
) -> VisionLanguageActivationExtractor:
    """
    Factory function to create an activation extractor.
    
    Automatically detects model type.
    """
    # Detect model type
    model_name = model.config._name_or_path.lower()
    
    if "gemma" in model_name:
        model_type = "gemma"
    elif "llama" in model_name:
        model_type = "llama"
    elif "mistral" in model_name:
        model_type = "mistral"
    else:
        model_type = "gemma"  # Default
    
    return VisionLanguageActivationExtractor(
        model=model,
        processor=processor,
        layers=layers,
        device=device,
        model_type=model_type
    )
