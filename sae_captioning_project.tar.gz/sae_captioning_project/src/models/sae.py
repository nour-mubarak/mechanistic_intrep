"""
Sparse Autoencoder Implementation
=================================

Production-ready SAE for mechanistic interpretability of vision-language models.
Includes TopK, standard L1, and Gated variants.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Optional, Tuple, Dict, Any, Literal
from dataclasses import dataclass
from einops import rearrange
import math


@dataclass
class SAEConfig:
    """Configuration for Sparse Autoencoder."""
    d_model: int
    expansion_factor: int = 8
    l1_coefficient: float = 5e-4
    normalize_decoder: bool = True
    tied_weights: bool = False
    activation: Literal["relu", "gelu", "topk"] = "relu"
    topk_k: int = 32  # Only used if activation == "topk"
    dtype: torch.dtype = torch.float32
    
    @property
    def d_hidden(self) -> int:
        return self.d_model * self.expansion_factor


class SparseAutoencoder(nn.Module):
    """
    Sparse Autoencoder for extracting interpretable features from neural activations.
    
    Architecture:
        - Pre-encoder bias subtraction (centering)
        - Linear encoder with ReLU/GELU/TopK activation
        - Linear decoder
        - Optional decoder weight normalization
    """
    
    def __init__(self, config: SAEConfig):
        super().__init__()
        self.config = config
        self.d_model = config.d_model
        self.d_hidden = config.d_hidden
        
        # Encoder: d_model -> d_hidden
        self.encoder = nn.Linear(config.d_model, config.d_hidden, bias=True)
        
        # Decoder: d_hidden -> d_model
        self.decoder = nn.Linear(config.d_hidden, config.d_model, bias=True)
        
        # Initialize weights
        self._init_weights()
        
        # Normalize decoder if specified
        if config.normalize_decoder:
            self._normalize_decoder()
    
    def _init_weights(self):
        """Initialize weights with Kaiming uniform."""
        nn.init.kaiming_uniform_(self.encoder.weight, a=math.sqrt(5))
        nn.init.kaiming_uniform_(self.decoder.weight, a=math.sqrt(5))
        
        # Initialize biases to zero
        nn.init.zeros_(self.encoder.bias)
        nn.init.zeros_(self.decoder.bias)
    
    def _normalize_decoder(self):
        """Normalize decoder columns to unit norm."""
        with torch.no_grad():
            self.decoder.weight.data = F.normalize(self.decoder.weight.data, dim=0)
    
    def encode(self, x: torch.Tensor) -> torch.Tensor:
        """
        Encode input activations to sparse feature space.
        
        Args:
            x: Input tensor of shape (..., d_model)
            
        Returns:
            Feature activations of shape (..., d_hidden)
        """
        # Center inputs by subtracting decoder bias
        x_centered = x - self.decoder.bias
        
        # Linear transformation
        pre_activation = self.encoder(x_centered)
        
        # Apply activation function
        if self.config.activation == "relu":
            features = F.relu(pre_activation)
        elif self.config.activation == "gelu":
            features = F.gelu(pre_activation)
        elif self.config.activation == "topk":
            features = self._topk_activation(pre_activation)
        else:
            raise ValueError(f"Unknown activation: {self.config.activation}")
        
        return features
    
    def _topk_activation(self, x: torch.Tensor) -> torch.Tensor:
        """TopK activation: keep only top k values per sample."""
        k = self.config.topk_k
        
        # Get top k indices
        topk_values, topk_indices = torch.topk(x, k=k, dim=-1)
        
        # Create sparse output
        output = torch.zeros_like(x)
        output.scatter_(-1, topk_indices, F.relu(topk_values))
        
        return output
    
    def decode(self, features: torch.Tensor) -> torch.Tensor:
        """
        Decode features back to activation space.
        
        Args:
            features: Feature tensor of shape (..., d_hidden)
            
        Returns:
            Reconstructed activations of shape (..., d_model)
        """
        return self.decoder(features)
    
    def forward(
        self, 
        x: torch.Tensor
    ) -> Tuple[torch.Tensor, torch.Tensor, Dict[str, torch.Tensor]]:
        """
        Forward pass through the SAE.
        
        Args:
            x: Input activations of shape (..., d_model)
            
        Returns:
            Tuple of (reconstruction, features, aux_info)
        """
        features = self.encode(x)
        reconstruction = self.decode(features)
        
        # Compute auxiliary information
        aux_info = {
            "l0_sparsity": (features > 0).float().sum(dim=-1).mean(),
            "mean_activation": features[features > 0].mean() if (features > 0).any() else torch.tensor(0.0),
            "max_activation": features.max(),
        }
        
        return reconstruction, features, aux_info
    
    def compute_loss(
        self,
        x: torch.Tensor,
        reconstruction: torch.Tensor,
        features: torch.Tensor,
        return_components: bool = False
    ) -> torch.Tensor | Tuple[torch.Tensor, Dict[str, torch.Tensor]]:
        """
        Compute SAE loss: reconstruction + L1 sparsity.
        
        Args:
            x: Original input
            reconstruction: Reconstructed input
            features: Encoded features
            return_components: Whether to return loss components
            
        Returns:
            Total loss, optionally with component breakdown
        """
        # Reconstruction loss (MSE)
        recon_loss = F.mse_loss(reconstruction, x)
        
        # Sparsity loss (L1)
        l1_loss = self.config.l1_coefficient * features.abs().mean()
        
        # Total loss
        total_loss = recon_loss + l1_loss
        
        if return_components:
            components = {
                "reconstruction_loss": recon_loss,
                "l1_loss": l1_loss,
                "total_loss": total_loss,
            }
            return total_loss, components
        
        return total_loss
    
    def get_feature_directions(self) -> torch.Tensor:
        """
        Get the decoder weight vectors (feature directions in activation space).
        
        Returns:
            Tensor of shape (d_hidden, d_model) containing feature directions
        """
        return self.decoder.weight.data.T.clone()
    
    def get_feature_norms(self) -> torch.Tensor:
        """Get L2 norms of decoder weight vectors."""
        return self.decoder.weight.data.norm(dim=0)


class GatedSparseAutoencoder(nn.Module):
    """
    Gated Sparse Autoencoder variant.
    
    Uses separate pathways for magnitude and gate, which can improve
    feature learning and reduce dead features.
    """
    
    def __init__(self, config: SAEConfig):
        super().__init__()
        self.config = config
        self.d_model = config.d_model
        self.d_hidden = config.d_hidden
        
        # Magnitude pathway
        self.W_mag = nn.Linear(config.d_model, config.d_hidden, bias=True)
        
        # Gate pathway
        self.W_gate = nn.Linear(config.d_model, config.d_hidden, bias=True)
        
        # Decoder
        self.decoder = nn.Linear(config.d_hidden, config.d_model, bias=True)
        
        # Learnable threshold for gating
        self.gate_threshold = nn.Parameter(torch.zeros(config.d_hidden))
        
        self._init_weights()
    
    def _init_weights(self):
        nn.init.kaiming_uniform_(self.W_mag.weight, a=math.sqrt(5))
        nn.init.kaiming_uniform_(self.W_gate.weight, a=math.sqrt(5))
        nn.init.kaiming_uniform_(self.decoder.weight, a=math.sqrt(5))
        
        nn.init.zeros_(self.W_mag.bias)
        nn.init.zeros_(self.W_gate.bias)
        nn.init.zeros_(self.decoder.bias)
    
    def encode(self, x: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Encode with gating mechanism.
        
        Returns:
            Tuple of (gated_features, gate_values)
        """
        x_centered = x - self.decoder.bias
        
        # Compute magnitude
        magnitude = F.relu(self.W_mag(x_centered))
        
        # Compute gate (sigmoid with learnable threshold)
        gate_logits = self.W_gate(x_centered) - self.gate_threshold
        gate = torch.sigmoid(gate_logits)
        
        # Apply gate
        features = magnitude * gate
        
        return features, gate
    
    def forward(
        self, 
        x: torch.Tensor
    ) -> Tuple[torch.Tensor, torch.Tensor, Dict[str, torch.Tensor]]:
        features, gate = self.encode(x)
        reconstruction = self.decoder(features)
        
        aux_info = {
            "l0_sparsity": (features > 0).float().sum(dim=-1).mean(),
            "gate_openness": gate.mean(),
            "mean_activation": features[features > 0].mean() if (features > 0).any() else torch.tensor(0.0),
        }
        
        return reconstruction, features, aux_info
    
    def compute_loss(
        self,
        x: torch.Tensor,
        reconstruction: torch.Tensor,
        features: torch.Tensor,
        return_components: bool = False
    ) -> torch.Tensor | Tuple[torch.Tensor, Dict[str, torch.Tensor]]:
        recon_loss = F.mse_loss(reconstruction, x)
        l1_loss = self.config.l1_coefficient * features.abs().mean()
        total_loss = recon_loss + l1_loss
        
        if return_components:
            return total_loss, {
                "reconstruction_loss": recon_loss,
                "l1_loss": l1_loss,
                "total_loss": total_loss,
            }
        return total_loss


class SAETrainer:
    """
    Training utilities for Sparse Autoencoders.
    """
    
    def __init__(
        self,
        sae: SparseAutoencoder | GatedSparseAutoencoder,
        learning_rate: float = 1e-4,
        warmup_steps: int = 1000,
        weight_decay: float = 0.0,
        device: str = "cuda",
    ):
        self.sae = sae.to(device)
        self.device = device
        
        self.optimizer = torch.optim.AdamW(
            sae.parameters(),
            lr=learning_rate,
            weight_decay=weight_decay,
            betas=(0.9, 0.999),
        )
        
        self.warmup_steps = warmup_steps
        self.step = 0
        self.learning_rate = learning_rate
    
    def get_lr(self) -> float:
        """Get current learning rate with warmup."""
        if self.step < self.warmup_steps:
            return self.learning_rate * (self.step / self.warmup_steps)
        return self.learning_rate
    
    def train_step(self, batch: torch.Tensor) -> Dict[str, float]:
        """
        Single training step.
        
        Args:
            batch: Tensor of activations, shape (batch_size, d_model)
            
        Returns:
            Dictionary of metrics
        """
        self.sae.train()
        batch = batch.to(self.device)
        
        # Update learning rate
        lr = self.get_lr()
        for param_group in self.optimizer.param_groups:
            param_group['lr'] = lr
        
        # Forward pass
        reconstruction, features, aux_info = self.sae(batch)
        
        # Compute loss
        loss, loss_components = self.sae.compute_loss(
            batch, reconstruction, features, return_components=True
        )
        
        # Backward pass
        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()
        
        # Normalize decoder weights if configured
        if hasattr(self.sae, 'config') and self.sae.config.normalize_decoder:
            self.sae._normalize_decoder()
        
        self.step += 1
        
        # Prepare metrics
        metrics = {
            "loss": loss.item(),
            "recon_loss": loss_components["reconstruction_loss"].item(),
            "l1_loss": loss_components["l1_loss"].item(),
            "l0_sparsity": aux_info["l0_sparsity"].item(),
            "learning_rate": lr,
            "step": self.step,
        }
        
        return metrics
    
    @torch.no_grad()
    def evaluate(self, dataloader: torch.utils.data.DataLoader) -> Dict[str, float]:
        """Evaluate SAE on validation data."""
        self.sae.eval()
        
        total_loss = 0
        total_recon = 0
        total_l1 = 0
        total_l0 = 0
        n_batches = 0
        
        for batch in dataloader:
            if isinstance(batch, (list, tuple)):
                batch = batch[0]
            batch = batch.to(self.device)
            
            reconstruction, features, aux_info = self.sae(batch)
            loss, components = self.sae.compute_loss(
                batch, reconstruction, features, return_components=True
            )
            
            total_loss += loss.item()
            total_recon += components["reconstruction_loss"].item()
            total_l1 += components["l1_loss"].item()
            total_l0 += aux_info["l0_sparsity"].item()
            n_batches += 1
        
        return {
            "val_loss": total_loss / n_batches,
            "val_recon_loss": total_recon / n_batches,
            "val_l1_loss": total_l1 / n_batches,
            "val_l0_sparsity": total_l0 / n_batches,
        }
    
    def save_checkpoint(self, path: str, epoch: int, metrics: Dict[str, float]):
        """Save training checkpoint."""
        checkpoint = {
            "epoch": epoch,
            "step": self.step,
            "model_state_dict": self.sae.state_dict(),
            "optimizer_state_dict": self.optimizer.state_dict(),
            "config": self.sae.config if hasattr(self.sae, 'config') else None,
            "metrics": metrics,
        }
        torch.save(checkpoint, path)
    
    def load_checkpoint(self, path: str) -> Dict[str, Any]:
        """Load training checkpoint."""
        checkpoint = torch.load(path, map_location=self.device)
        self.sae.load_state_dict(checkpoint["model_state_dict"])
        self.optimizer.load_state_dict(checkpoint["optimizer_state_dict"])
        self.step = checkpoint["step"]
        return checkpoint


def create_sae(
    d_model: int,
    expansion_factor: int = 8,
    l1_coefficient: float = 5e-4,
    sae_type: Literal["standard", "gated"] = "standard",
    **kwargs
) -> SparseAutoencoder | GatedSparseAutoencoder:
    """
    Factory function to create SAE instances.
    
    Args:
        d_model: Model hidden dimension
        expansion_factor: SAE expansion factor
        l1_coefficient: L1 sparsity coefficient
        sae_type: Type of SAE ("standard" or "gated")
        **kwargs: Additional config parameters
        
    Returns:
        Configured SAE instance
    """
    config = SAEConfig(
        d_model=d_model,
        expansion_factor=expansion_factor,
        l1_coefficient=l1_coefficient,
        **kwargs
    )
    
    if sae_type == "standard":
        return SparseAutoencoder(config)
    elif sae_type == "gated":
        return GatedSparseAutoencoder(config)
    else:
        raise ValueError(f"Unknown SAE type: {sae_type}")
