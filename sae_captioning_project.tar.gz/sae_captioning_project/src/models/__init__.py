"""
Models module for SAE-based interpretability.
"""

from .sae import (
    SAEConfig,
    SparseAutoencoder,
    GatedSparseAutoencoder,
    SAETrainer,
    create_sae,
)

from .hooks import (
    HookConfig,
    ActivationCache,
    VisionLanguageActivationExtractor,
    create_activation_extractor,
)

__all__ = [
    "SAEConfig",
    "SparseAutoencoder",
    "GatedSparseAutoencoder",
    "SAETrainer",
    "create_sae",
    "HookConfig",
    "ActivationCache",
    "VisionLanguageActivationExtractor",
    "create_activation_extractor",
]
